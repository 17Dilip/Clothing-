-- Run this once in Supabase: Project -> SQL Editor -> New query -> paste -> Run

create table if not exists kv_store (
  key text primary key,
  value text,
  updated_at timestamptz default now()
);

-- Row Level Security must be enabled, then we add a permissive policy
-- so the anon key (used by the browser) can read/write.
-- This matches how the site currently works (no server, plain-text data),
-- so treat it as a demo/prototype setup rather than production-grade security.
alter table kv_store enable row level security;

create policy "public read" on kv_store
  for select using (true);

create policy "public write" on kv_store
  for insert with check (true);

create policy "public update" on kv_store
  for update using (true);

create policy "public delete" on kv_store
  for delete using (true);
